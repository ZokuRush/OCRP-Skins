Thanks for buying my vehicle skins but now lets get these installed on ur server! To Install these is pretty easy but can be kind of confusing if its ur first time I'm gonna try my best to help you install these and have these working on ur server in no time!

Install Video: https://www.youtube.com/watch?v=knMKffiKqmU
(This isnt my video but it will help you!)

My Discord for support Zoku#1298